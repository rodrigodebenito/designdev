﻿<?php

	// Love, John Niedermeyer – http://nieder.me
	
	
	// if your comps are in a subfolder, list it here. Must end with a slash, e.g., ‘comps/’.
	// Default is nothing, (i.e., in the same folder as this PHP file)
	$dir = "";


	// Page <title/>. (e.g., Project name)
	// Default is nothing
	$siteTitle = "";
	
	
	// Background-color for the stage. (Any CSS hex or name value, e.g., #f4f4f4, lightgray)
	// Default is ‘white’
	$bgColor = "white";


	// Nav Bar: ‘dark’ or ‘light’ theme? 
	// Default is ‘dark’
	$navTheme = "dark";


	// Nav Bar: fixie ‘yes’ or ‘no’? 
	// Default is ‘yes’
	$navFixie = "yes";
	
	
	// Include previous and next arrows in the viewport. 
	// Default is ‘yes’.
	$viewportPrevNext = "yes";
	
	
	// Are these comps mobile? Set to yes for omptized viewing on phones.
	// Default is ‘no’.
	$mobileComps = "no";


	// Set a comment for each slide, in the order that they appear. 
	// For an empty slide, include space between quotes (" ").
	// If you want to include HTML or Bootstrap hooks, take care to use single quotes (') or escape your double quotes ("). E.g., <a href='#'/>, not <a href="#"/>
	// Default is nothing
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";


	// Override CSS — for instance, with iOS mocks, you migtht want to full-bleed the comps.
	// Default is nothing

	$cssOverride = "
		
			.exampleClass {
				
			}
		
	";
	

	// Go!
	include '/web/design/docs/apps/rotator/v2/code/rotator.php'; 

?>