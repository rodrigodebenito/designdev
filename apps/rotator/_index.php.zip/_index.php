﻿<?php
error_reporting(E_ALL ^ E_NOTICE);
ob_start();




// Edit Configuration //////////////////////////////////////////////////////////////
	
	// Site title
	$sitetitle = " "; 

	// This is your sites description, (used in meta tags)
	$sitedescription = " ";

	// Main domain of your site
	$mainsiteurl = " "; 

	// Full URL to the index.php directory, (must end with a slash)
	$fullpath = " "; 

	// Image directory, (if a subfolder is desired, must end with a slash)
	
	$dir = "./";

	// Image sort – if true, images are sorted according to time stamp. If false, images are sorted by name.
	$datedriven = false;

	// Order sort – if true, images sort by name high to low. If false, low to high.
	$highest_lowest = false;

	// Get background color from file name – true or false
	$getbackgroundcolorfromfilename = false; 

	// Default background color
	$defaultbackcolor = "#fff"; 

	// Auto play – if true, slides advance after delay
	$playdefault = false;

	// Auto play slide delay – in seconds
	$delay = 3; 

	// Set a comment for each slide, in the order that they appear. For an empty slide, include space between quotes.
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	$comment[] = " ";
	
// End Configuration – Do not edit below //////////////////////////////////////////////////////////////
	
	
	
	
	
	
	
	include '/web/design/docs/apps/rotator/code.php'; 
	echo $jscript_slideshow;

	?>

<!DOCTYPE html lang="en-us">
<html lang="en">
	<head>
	
	<meta charset="utf-8"> 
	<meta name="description" content="<?php echo $sitedescription ?>" /> 
	
	<title><?php echo $sitetitle . " - Page ". $pg . " of " . $imgcount; ?></title>
	
	<link rel="stylesheet" type="text/css" href="/apps/rotator/styles.css">
	
	<?php	
	
	?>
	
	</head>
	<body>
	
	<div id="floater">
		<table>
			<tr>
					<td valign="top">
						<div id="nav">
							<ul>
								<li><a href="<?php echo $thisfilename ?>?pg=<?php echo $prevpage; ?>" class="prev" title="previous">◄</a></li>
								<li><a href="<?php echo $thisfilename ?>?pg=<?php echo $nextpage; ?>" class="next" title="next">►</a></li>
							</ul>
							<p><?php echo $pg . " of " . $imgcount;?></p>
						</div>
					</td>
					<td valign="top">
						<div id="navpage">
							<?php 
								if (isset($pg)) {
									$Files[$pg] = str_replace('.png', '', $Files[$pg]);
									$Files[$pg] = str_replace('.jpg', '', $Files[$pg]);
									$Files[$pg] = str_replace('-', ' ', $Files[$pg]);
									$Files[$pg] = str_replace('_', ' ', $Files[$pg]);
					
									echo "<form action='' name='navform'>
									<select name='navigate' onchange='window.open(navform.navigate.options[navform.navigate.selectedIndex].value,\"_top\")'>";
					
									for ($i = 1; $i <= $imgcount; $i++) {
										echo "<option value='?pg=" . $i . "'";
						
										if ($i == $pg) {
											echo " selected";
										} else { 
											echo "";
										}
										$Files[$i] = str_replace('.png', '', $Files[$i]);
										$Files[$i] = str_replace('-', ' ', $Files[$i]);
										echo ">" . $Files[$i] . "</option>";
									}
					
									echo "</select>";
							?>
						</div>
					</td>
					<td valign="top">
						<?php				
							if ($comment[$pg] != "") {
								echo "<div id='navcomment'>" . $comment[$pg-1] . "</div>";
							} else {
								echo "";
							}
							echo "</form>";

					
							} else {
								echo "";
							}
						?>
					</td>
				</tr>
			</table>
		</div>

		<div id="pageimg">
			<a href="<?php echo $thisfilename ?>?pg=<?php echo $nextpage; ?>"><img src="<?php echo $imagesource; ?>" alt="<?php echo $thisfilename ?>" height="<?php echo $imageheight; ?>" width="<?php echo $imagewidth; ?>" border="0" /></a>
		</div>

	</body>
</html>